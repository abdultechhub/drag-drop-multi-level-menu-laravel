<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\MenuItemController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('manage-menus',[MenuItemController::class,'index']);

Route::post('update-menu',[MenuItemController::class,'updateMenu'])->name('menu.update');	
Route::post('/post/post_order_change', [MenuItemController::class, 'post_order_change'])->name('post.order_change');

Route::POST('menu/change_parent_menu', [MenuItemController::class, 'change_parent_menu'])->name('change_parent_menu');



