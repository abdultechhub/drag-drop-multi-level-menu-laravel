<ul class="example post_sortable">
    <?php $__currentLoopData = $child_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-id="<?php echo e($child->id); ?>" data-parentid="<?php echo e($p_menu_item->parent_id); ?>"
            data-position="<?php echo e($child->position); ?>">

            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapse_<?php echo e($child->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                    <?php echo e($child->name); ?>


                    <select name="change_parent" onchange="change_parent(this.value, <?php echo e($child->id); ?>)"
                        class="form-select form-select-sm">
                        <option value=""> Select Parent </option>
                        <option value="0"> No parent </option>
                        <?php $__currentLoopData = $all_menu_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($all_item->id != $child->id): ?>
                                <?php if(count($child->child_menu) <= 0): ?>
                                    <option value="<?php echo e($all_item->id); ?>"><?php echo e($all_item->name); ?></option>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </button>
            </h2>
            <div id="collapse_<?php echo e($child->id); ?>" class="accordion-collapse collapse" aria-labelledby="headingThree"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It
                    is hidden by
                </div>
            </div>



            <?php if(count($child->child_menu)): ?>
                <?php echo $__env->make('menu.child_menu', ['child_menus' => $child->child_menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/child_menu.blade.php ENDPATH**/ ?>