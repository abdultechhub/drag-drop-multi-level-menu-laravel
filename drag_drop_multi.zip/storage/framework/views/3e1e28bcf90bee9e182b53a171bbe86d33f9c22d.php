<ul>
    <?php $__currentLoopData = $childcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <div class="checkbox">
                <input type="checkbox" name="category[]" id="cat_<?php echo e($child->id); ?>" value="<?php echo e($child->id); ?>">
                <label for="cat_<?php echo e($child->id); ?>" class="custom-unchecked"> <?php echo e($child->name); ?></label>
            </div>
            <?php if(count($child->ChildCategory)): ?>
                <?php echo $__env->make('menu.manageChild', ['childcategories' => $child->ChildCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/manageChild.blade.php ENDPATH**/ ?>