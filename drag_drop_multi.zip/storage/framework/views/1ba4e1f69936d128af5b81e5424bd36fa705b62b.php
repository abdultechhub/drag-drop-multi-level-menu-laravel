<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel Drag Drop Reordering</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"
        integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"
        integrity="sha256-lSjKY0/srUM9BE3dPm+c4fBo1dky2v27Gdjm2uoZaL0=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
        integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
    <style>
        .post_list_ul {
            margin: 0px;
            padding: 5px;
        }

        .post_list_ul li {
            list-style: none;
            padding: 0;
            background: #fff;
            box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.3);

            cursor: move;
            position: relative;
            font-size: 16px;
            border-radius: 5px;
            margin-bottom: 10px;
        }


        /* .post_list_ul li .pos_num {
            display: inline-block;
            padding: 2px 5px;
            height: 20px;
            line-height: 17px;
            background: rgb(6, 160, 65);
            color: #fff;
            text-align: center;
            border-radius: 5px;
            position: absolute;
            left: -5px;
            top: 6px;
        } */

        /* .post_list_ul li:hover {
            list-style: none;
            background: #e6dcff;

        } */

        .post_list_ul li.ui-state-highlight {
            padding: 20px;
            background-color: #d4fdcc;
            border: 1px dotted #ccc;
            cursor: move;
            margin-top: 12px;
        }

        .post_list_ul .btn_move {
            display: inline-block;
            cursor: move;
            background: #ededed;
            border-radius: 2px;
            width: 30px;
            height: 30px;
            text-align: center;
            line-height: 30px;
        }

        .accordion-button {
            padding: 5px 10px;
            font-size: 1rem;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .accordion-button select {
            width: 180px;
            max-width: 100%;
            margin-left: 20px;
        }
    </style>
</head>

<body>
    <div class="container p-3">
        <div class="row">

            <div class="col-md-12">

                <?php if(session('message')): ?>
                    <h3 style="color:green"><?php echo e(session('message')); ?></h3>
                <?php endif; ?>
            </div>

            <div class="col-md-12">

                <div class="card">
                    <div class="card-header with-border d-flex justify-content-between align-items-center">
                        Drag Drop To changes Post Order

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <div id="example1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12">

                                        <?php
                                            function generateOptions($items, $parentId = 0, $level = 0, $excludeIds = [])
                                            {
                                                foreach ($items as $item) {
                                                    // Exclude child items
                                                    if (in_array($item->id, $excludeIds)) {
                                                        continue;
                                                    }
                                            
                                                    // Indent the option based on the level
                                                    $indent = str_repeat('&nbsp;', $level * 4);
                                            
                                                    // Output the option element
                                                    echo '<option value="' . $item->id . '">' . $indent . $item->name . '</option>';
                                            
                                                    // Recursively call the function for child items
                                                    if ($item->parent_id == $parentId) {
                                                        generateOptions($items, $item->id, $level + 1, $excludeIds);
                                                    }
                                                }
                                            }
                                        ?>

                                        <ul id="post_sortable" class="post_list_ul post_sortable accordion">
                                            <?php $__currentLoopData = $parent_menu_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-id="<?php echo e($p_menu_item->id); ?>" class="accordion-item">
                                                    <h2 class="accordion-header" id="headingOne">
                                                        <button class="accordion-button" type="button"
                                                            data-bs-toggle="collapse"
                                                            data-bs-target="#collapse_<?php echo e($p_menu_item->id); ?>"
                                                            aria-expanded="true" aria-controls="collapseOne">
                                                            <?php echo e($p_menu_item->name); ?>

                                                            <select name="parent_id">
                                                                <option value="">Select Parent</option>
                                                                <?php generateOptions($all_menu_item); ?>
                                                            </select>

                                                            <select name="change_parent"
                                                                class="form-select form-select-sm"
                                                                onchange="change_parent(this.value,<?php echo e($p_menu_item->id); ?>)">
                                                                <option value=""> Select Parent </option>
                                                                <option value="0"> No parent </option>
                                                                <?php $__currentLoopData = $all_menu_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($all_item->id != $p_menu_item->id): ?>
                                                                        <?php if(count($p_menu_item->child_menu) <= 0): ?>
                                                                            <option value="<?php echo e($all_item->id); ?>">
                                                                                <?php echo e($all_item->name); ?>

                                                                            </option>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </button>
                                                    </h2>
                                                    <div id="collapse_<?php echo e($p_menu_item->id); ?>"
                                                        class="accordion-collapse collapse"
                                                        aria-labelledby="headingThree"
                                                        data-bs-parent="#accordionExample">
                                                        <div class="accordion-body">
                                                            <strong>This is the third item's accordion body.</strong> It
                                                            is hidden by
                                                        </div>
                                                    </div>



                                                    <?php if(count($p_menu_item->child_menu)): ?>
                                                        <?php echo $__env->make('menu.child_menu', [
                                                            'child_menus' => $p_menu_item->child_menu,
                                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>

            </div>
        </div>

    </div>


    <script>
        function change_parent(parent_id, id) {
            console.log(parent_id);
            $.ajax({
                type: "POST",
                dataType: "json",
                url: '/menu/change_parent_menu',
                data: {
                    'id': id,
                    'parent_id': parent_id,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(data) {
                    toastr.success(data.message);
                    location.reload();
                }
            });
        }


        $(document).ready(function() {
            $(".post_sortable").sortable({
                placeholder: "ui-state-highlight",
                // connectWith: ".post_sortable",
                update: function(event, ui) {
                    //var data = $(this).sortable('toArray');

                    var post_order_ids = new Array();
                    $('#post_sortable li').each(function() {
                        post_order_ids.push($(this).data("id"));
                    });

                    console.log(post_order_ids);
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('post.order_change')); ?>",
                        dataType: "json",
                        data: {
                            order: post_order_ids,
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            toastr.success(response.message);
                            $('#post_sortable li').each(function(index) {
                                $(this).find('.pos_num').text(index + 1);

                                //console.log(index);
                            });

                        },
                        error: function(xhr, status, error) {
                            console.log(xhr.responseText);
                        }
                    });
                }
            });
        });
    </script>

</body>

</html>
<?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/menu.blade.php ENDPATH**/ ?>