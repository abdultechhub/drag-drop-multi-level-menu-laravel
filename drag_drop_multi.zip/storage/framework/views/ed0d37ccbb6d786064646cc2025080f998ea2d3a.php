
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h2><span>Menus</span></h2>

        <div class="row" id="main-row">
            <div id="menu-content">
                <div id="result"></div>
                


                <ul class="menu ui-sortable example" id="menuitems">
                    <?php $__currentLoopData = $parent_menu_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-id="<?php echo e($p_menu_item->id); ?>" data-parentid="<?php echo e($p_menu_item->parent_id); ?>"
                            data-position="<?php echo e($p_menu_item->position); ?>">
                            <?php echo e($p_menu_item->name); ?>

                            <ul>
                            </ul>
                            <?php if(count($p_menu_item->child_menu)): ?>
                                <?php echo $__env->make('menu.child_menu', [
                                    'child_menus' => $p_menu_item->child_menu,
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>


                <button type="button" id="saveMenu" class="btn btn-primary">Save Mneu</button>

            </div>

        </div>
    </div>
    <div class="col-md-6">

        <pre id="serialize_output">
        
       </pre>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        if ('addEventListener' in window) {
            window.addEventListener('scroll', function(e) {
                // Your code here
            }, {
                passive: true
            });
        } else {
            window.attachEvent('onscroll', function(e) {
                // Your code here
            });
        }


        var group = $("#menuitems").sortable({
            group: 'serialization',
            onDrop: function($item, container, _super) {
                // get all the list items
                var $listItems = container.el.find('li');
                // loop through the list items and update their data-position attribute
                $listItems.each(function(index, listItem) {
                    $(listItem).attr('data-position', index + 1);
                });

                var data = group.sortable("serialize").get();
                var jsonString = JSON.stringify(data, null, ' ');
                $('#serialize_output').text(jsonString);
                _super($item, container);
            },
            onDragStart: function($item, container, _super) {
                $item.addClass('ui-sortable-placeholder-highlight');
                _super($item, container);
            },
            onDragStop: function($item, container, _super) {
                $item.removeClass('ui-sortable-placeholder-highlight');
                container.el.addClass('ui-sortable-highlight');
                setTimeout(function() {
                    container.el.removeClass("ui-sortable-highlight");
                }, 300);
                _super($item, container);
            }
        });

        // add highlight class to the items without nested elements
        $("#menuitems li:not(:has(ul))").addClass('ui-sortable-placeholder-highlight');


        $('#saveMenu').click(function() {
            var menuid = 1;
            var location = 'header';
            var newText = $("#serialize_output").text();
            var data = JSON.parse($("#serialize_output").text());
            console.log(data);
            $.ajax({
                type: "get",
                data: {
                    menuid: menuid,
                    data: data,
                    location: location
                },
                url: "<?php echo e(url('update-menu')); ?>",
                success: function(res) {
                    console.log(res);
                    // window.location.reload();
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/index.blade.php ENDPATH**/ ?>