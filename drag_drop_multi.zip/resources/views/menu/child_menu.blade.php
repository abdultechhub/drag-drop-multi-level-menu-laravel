<ul class="example post_sortable">
    @foreach ($child_menus as $child)
        <li data-id="{{ $child->id }}" data-parentid="{{ $p_menu_item->parent_id }}"
            data-position="{{ $child->position }}">

            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapse_{{ $child->id }}" aria-expanded="true" aria-controls="collapseOne">
                    {{ $child->name }}

                    <select name="change_parent" onchange="change_parent(this.value, {{ $child->id }})"
                        class="form-select form-select-sm">
                        <option value=""> Select Parent </option>
                        <option value="0"> No parent </option>
                        @foreach ($all_menu_item as $all_item)
                            @if ($all_item->id != $child->id)
                                @if (count($child->child_menu) <= 0)
                                    <option value="{{ $all_item->id }}">{{ $all_item->name }}</option>
                                @endif
                            @endif
                        @endforeach
                    </select>
                </button>
            </h2>
            <div id="collapse_{{ $child->id }}" class="accordion-collapse collapse" aria-labelledby="headingThree"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It
                    is hidden by
                </div>
            </div>



            @if (count($child->child_menu))
                @include('menu.child_menu', ['child_menus' => $child->child_menu])
            @endif
        </li>
    @endforeach
</ul>
