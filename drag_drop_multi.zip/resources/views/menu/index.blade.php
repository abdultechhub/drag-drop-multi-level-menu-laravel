@extends('master')
@section('content')
    <div class="container-fluid">
        <h2><span>Menus</span></h2>

        <div class="row" id="main-row">
            <div id="menu-content">
                <div id="result"></div>
                {{-- <ul class="menu ui-sortable" id="">
                    <li>Link </li>
                    <li>Link 2</li>
                    <li>Link</li>
                    <li>Link 4</li>
                    <li>Link</li>
                </ul> --}}


                <ul class="menu ui-sortable example" id="menuitems">
                    @foreach ($parent_menu_item as $p_menu_item)
                        <li data-id="{{ $p_menu_item->id }}" data-parentid="{{ $p_menu_item->parent_id }}"
                            data-position="{{ $p_menu_item->position }}">
                            {{ $p_menu_item->name }}
                            <ul>
                            </ul>
                            @if (count($p_menu_item->child_menu))
                                @include('menu.child_menu', [
                                    'child_menus' => $p_menu_item->child_menu,
                                ])
                            @endif
                        </li>
                    @endforeach
                </ul>


                <button type="button" id="saveMenu" class="btn btn-primary">Save Mneu</button>

            </div>

        </div>
    </div>
    <div class="col-md-6">

        <pre id="serialize_output">
        
       </pre>

    </div>
@endsection

@section('custom_js')
    <script>
        if ('addEventListener' in window) {
            window.addEventListener('scroll', function(e) {
                // Your code here
            }, {
                passive: true
            });
        } else {
            window.attachEvent('onscroll', function(e) {
                // Your code here
            });
        }


        var group = $("#menuitems").sortable({
            group: 'serialization',
            onDrop: function($item, container, _super) {
                // get all the list items
                var $listItems = container.el.find('li');
                // loop through the list items and update their data-position attribute
                $listItems.each(function(index, listItem) {
                    $(listItem).attr('data-position', index + 1);
                });

                var data = group.sortable("serialize").get();
                var jsonString = JSON.stringify(data, null, ' ');
                $('#serialize_output').text(jsonString);
                _super($item, container);
            },
            onDragStart: function($item, container, _super) {
                $item.addClass('ui-sortable-placeholder-highlight');
                _super($item, container);
            },
            onDragStop: function($item, container, _super) {
                $item.removeClass('ui-sortable-placeholder-highlight');
                container.el.addClass('ui-sortable-highlight');
                setTimeout(function() {
                    container.el.removeClass("ui-sortable-highlight");
                }, 300);
                _super($item, container);
            }
        });

        // add highlight class to the items without nested elements
        $("#menuitems li:not(:has(ul))").addClass('ui-sortable-placeholder-highlight');


        $('#saveMenu').click(function() {
            var menuid = 1;
            var location = 'header';
            var newText = $("#serialize_output").text();
            var data = JSON.parse($("#serialize_output").text());
            console.log(data);
            $.ajax({
                type: "get",
                data: {
                    menuid: menuid,
                    data: data,
                    location: location
                },
                url: "{{ url('update-menu') }}",
                success: function(res) {
                    console.log(res);
                    // window.location.reload();
                }
            })
        })
    </script>
@endsection
