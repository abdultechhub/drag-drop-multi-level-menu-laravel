<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MenuItem;

class MenuItemController extends Controller
{
    public function index(){
        $parent_menu_item = MenuItem::where('parent_id', 0)->orderBy('position', 'asc')->get();
        $all_menu_item = MenuItem::orderBy('position', 'asc')->get();
        return view ('menu.menu', compact('parent_menu_item', 'all_menu_item'));
      }

    public function updateMenu(Request $request){
        //    $new_array =  array_shift($request->data);
        //    print_r($new_array);

        $data  = $request->data;

        $new_data = $data[0];
        // $this->saveMenu($new_data, 0);
    }
    public function change_parent_menu(Request $request){
        //dd($request->all());

        $parent_id = MenuItem::findOrFail($request->id);

        $parent_id->parent_id = $request->parent_id;

        $parent_id->save();
        return  response()->json([
            'message' => 'Post status change successfully.',
            'alert-type' => 'success'
        ]);
    }

    public function getOptions($parent_id = null, $exclude_id = null)
        {
            $options = [];

            $items =MenuItem::
                 where('parent_id', $parent_id)
                ->where('id', '<>', $exclude_id)
                ->get();

            foreach ($items as $item) {
                $options[$item->id] = $prefix . $item->name;
                $options += $this->getOptions($item->id, $exclude_id);
            }

            return $options;
        }

    public function saveMenu($menu, $parentId = null)
    {
        foreach ($menu as $index => $item) {
            //echo $item['id'];
            if (!isset($item['id'])) {
                continue;
                $menuItem = MenuItem::find($item['id']);
                $menuItem->parent_id = $parentId ?? 0; // set parent_id to 0 if there is no parent
                $menuItem->position = $index + 1;
                $menuItem->save();

            // echo $item[$index]['children'];

            //print_r(count($item['children']));
                
                if (isset($item['children']) && count($item['children'])) {
                    // pass 0 as parentId if $parentId is null
                    // echo $parentId;
                    $this->saveMenu($item['children'], $parentId ?? 0);
                }
            }
        }
    }


        public function post_order_change(Request $request)
        {
        $data = $request->input('order');
            foreach ($data as $index => $id) {
                MenuItem::where('id', $id)->update(['position' => $index]);
            }
            return  response()->json([

                'message' => 'Post Order changed successfully.',

                'alert-type' => 'success'

            ]);
        //return response()->json(['success' => $data]);
        }

    
}
