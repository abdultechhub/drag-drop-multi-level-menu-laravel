
<?php $__env->startSection('content'); ?>
    <div class="container p-3">
        <div class="row">


            <div class="col-md-12">

                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <div id="example1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12">

                                        <h3>Edit Menu</h3>

                                        <form action="<?php echo e(route('menu.update', $menu)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            <div class="mb-3">
                                                <label for="menu_name" class="form-label">Menu Name</label>
                                                <input type="text" class="form-control" name="menu_name" required
                                                    value="<?php echo e($menu->title ?? ''); ?>">
                                            </div>
                                            <h4 class="mt-4">Change location</h4>
                                            <div class="mb-3 form-check">
                                                <input type="radio" class="form-check-input" name="menu_location"
                                                    value="header" id="menu_location_h"
                                                    <?php echo e($menu->location == 'header' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="menu_location_h">Header Menu</label>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="radio" class="form-check-input" name="menu_location"
                                                    value="footer" id="menu_location_f"
                                                    <?php echo e($menu->location == 'footer' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="menu_location_f">Footer Menu</label>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="radio" class="form-check-input" name="menu_location"
                                                    value="sidebar" id="menu_location_s"
                                                    <?php echo e($menu->location == 'sidebar' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="menu_location_s">Sidebar Menu</label>
                                            </div>

                                            <button type="submit" class="btn btn-primary">Update Menu</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/edit.blade.php ENDPATH**/ ?>