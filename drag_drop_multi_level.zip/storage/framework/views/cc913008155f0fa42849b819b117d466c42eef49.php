<form action="<?php echo e(route('menu.change_menu_location', $id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="card mt-5">

        <div class="card-body">
            <h4>Change Menu Location</h4>
            <?php if(!empty($menu_single)): ?>
                <div class="mb-3 form-check">
                    <input type="radio" class="form-check-input" name="menu_location" value="header" id="menu_location_h"
                        <?php echo e($menu_single->location == 'header' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="menu_location_h">Header Menu</label>
                </div>
                <div class="mb-3 form-check">
                    <input type="radio" class="form-check-input" name="menu_location" value="footer"
                        id="menu_location_f" <?php echo e($menu_single->location == 'footer' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="menu_location_f">Footer Menu</label>
                </div>
                <div class="mb-3 form-check">
                    <input type="radio" class="form-check-input" name="menu_location" value="sidebar"
                        id="menu_location_s" <?php echo e($menu_single->location == 'sidebar' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="menu_location_s">Sidebar Menu</label>
                </div>
            <?php endif; ?>

        </div>
        <div class="card-footer text-end">
            <button class="btn btn-primary">Save Menu Location</button>
        </div>

    </div>
</form>
<?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/change_menu_location.blade.php ENDPATH**/ ?>