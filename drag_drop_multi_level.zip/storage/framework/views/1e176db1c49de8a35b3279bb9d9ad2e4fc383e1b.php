<ul class="example post_sortable">
    <?php $__currentLoopData = $child_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-id="<?php echo e($child->id); ?>" data-parentid="<?php echo e($parent_menu_item->parent_id); ?>"
            data-position="<?php echo e($child->position); ?>">

            <div class="accordion-header" id="headingOne">
                <div class="header_left">
                    <?php echo e($child->name); ?>


                    <select name="change_parent" onchange="change_parent(this.value, <?php echo e($child->id); ?>)"
                        class="form-select form-select-sm">
                        <option value=""> Select Parent Menu</option>
                        <option value="0"> No parent</option>
                        <?php $__currentLoopData = $all_menu_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($menu_item->id != $child->id && !$menu_item->isDescendantOf($child)): ?>
                                <option value="<?php echo e($menu_item->id); ?>"><?php echo e($menu_item->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <form action="<?php echo e(route('menu.delete_menu', $child->id)); ?>" method="POST"
                    onsubmit="return confirm('Are you sure you want to delete this post?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn delete_button"><i class="fa-solid fa-trash"></i></button>
                </form>
                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapse_<?php echo e($child->id); ?>" aria-expanded="false" aria-controls="collapseOne">

                </button>
            </div>
            <div id="collapse_<?php echo e($child->id); ?>" class="accordion-collapse collapse" aria-labelledby="headingThree"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <form action="<?php echo e(route('menu.add_custom_link')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="menu_id" value="1">
                        <div class="mb-3">
                            <label for="menu_label" class="form-label">Label</label>
                            <input type="text" class="form-control" name="menu_label"
                                value="<?php echo e($menu_item->name ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="menu_link" class="form-label">Link</label>
                            <input type="text" class="form-control" name="menu_link"
                                value="<?php echo e($menu_item->slug ?? ''); ?>">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="menu_target"
                                value="<?php echo e($menu_item->target ?? ''); ?>"
                                <?php echo e($menu_item->target == '_balnk' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="menu_target">Open New Tab</label>
                        </div>
                        <button type="submit" class="btn btn-primary">Update
                            menu</button>
                    </form>
                </div>
            </div>

            <?php if(count($child->child_menu)): ?>
                <?php echo $__env->make('menu.child_menu', [
                    'child_menus' => $child->child_menu,
                    'parent_menu_item' => $child,
                    'all_menu_item' => $all_menu_item,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/child_menu.blade.php ENDPATH**/ ?>