
<?php $__env->startSection('content'); ?>
    <div class="container p-3">
        <div class="row">


            <div class="col-md-12">

                <div class="card">
                    <div class="card-header with-border ">
                        <?php echo $__env->make('menu.create_menu_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <div id="example1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12">

                                        <table class="table border table-striped table-hover">
                                            <thead>
                                                <tr class="bg-light">
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Mange Menu Items</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->index); ?></td>
                                                        <td><?php echo e($item->title); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('menu.menu', $item)); ?>"
                                                                class="btn btn-primary btn-sm" title="Edit Data">Manage
                                                                items</a>
                                                        </td>
                                                        <td>
                                                            <a href="<?php echo e(route('menu.edit', $item)); ?>"
                                                                class="btn edit_button" title="Edit Data"><i
                                                                    class="fa fa-pencil"></i></a>
                                                            <form action="<?php echo e(route('menu.destroy', $item)); ?>" method="POST"
                                                                onsubmit="return confirm('Are you sure you want to delete this post?')">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn delete_button ms-3"><i
                                                                        class="fa-solid fa-trash"></i></button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>

                                        </table>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\abdul\drag_drop_menu_multi_level\resources\views/menu/index.blade.php ENDPATH**/ ?>